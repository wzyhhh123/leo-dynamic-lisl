"""One-time migration of archived initial states into frozen synthetic TLEs."""
from pathlib import Path
import sys
import traceback
import shutil
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from dynamic_lisl.common import *
from dynamic_lisl.sgp4_model import parse_tle,tle_mean_elements,Sgp4Model


def main():
    import argparse
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--limit',type=int)
    args=p.parse_args()
    source=PROJECT/'archive/twobody_20260921/outputs/gate_a_720_20260918T124844_819817Z'
    bundle=PROJECT/'data/raw/sgp4_x720'
    if args.limit is None and bundle.exists():raise FileExistsError('Frozen bundle already exists; never overwrite')
    prov=read_json(source/'provenance.json')['output_hashes']
    for name,expected in prov.items():
        f=(source/name).resolve()
        if source.resolve() not in f.parents or sha(f)!=expected:raise ValueError('Archive source hash mismatch: '+name)
    rows=read_json(source/'constellation_manifest.json')
    if args.limit is not None:
        if not 1<=args.limit<=len(rows):raise ValueError('Invalid limit')
        rows=rows[:args.limit]
    out=new_output('sgp4_fit');status=dict(overall='RUNNING',count=len(rows),source_archive=str(source))
    dump(out/'status.json',status);app=None;owns=False
    try:
        from comtypes.client import CreateObject
        app=CreateObject('STK11.Application');root=app.Personality2
        if bool(root.CurrentScenario):raise RuntimeError('REFUSE_NONEMPTY_STK')
        owns=True;app.Visible=False;app.UserControl=False
        root.LoadScenario(str(source/'scenario.sc'));units(root)
        records=[];fits=[]
        for j,row in enumerate(rows):
            obj=root.GetObjectFromPath('*/Satellite/'+row['source_name'])
            r0,v0=rv(obj,EPOCH,'TEMEOfDate')
            ssc=10000+row['plane_id']*40+row['slot_id'];name='Fit_'+row['sat_name']
            cmd=f'GenerateTLE */Satellite/{row["source_name"]} Point "{EPOCH}" {ssc} 100 0.0000000001 SGP4 "{name}" BStar 0'
            root.ExecuteCommand(cmd)
            dp=obj.DataProviders.GetDataPrvFixedFromPath('TLE Summary Data').Exec()
            lines=list(dp.DataSets.GetDataSetByName('TLE').GetValues())
            if len(lines)!=2:raise ValueError('Expected two TLE lines')
            model=parse_tle(lines[0],lines[1],ssc)
            error,r,v=model.sgp4(EPOCH_JD,0.0)
            dr=float(np.linalg.norm(np.asarray(r)-r0)*1000);dv=float(np.linalg.norm(np.asarray(v)-v0)*1000)
            if error or dr>25 or dv>0.05:raise ValueError('SERIALIZED_TLE_EPOCH_FIT_FAILED: '+str((row['sat_name'],dr,dv,error)))
            rms=float(dp.DataSets.GetDataSetByName('Final RMS').GetValues()[0])
            fit=dict(sat_name=row['sat_name'],serialized_epoch_position_error_m=dr,serialized_epoch_velocity_error_m_s=dv,stk_fit_final_rms_km=rms if np.isfinite(rms) else None,stk_fit_rms_available=bool(np.isfinite(rms)))
            fits.append(fit)
            records.append(dict(sat_name=row['sat_name'],plane_id=row['plane_id'],slot_id=row['slot_id'],ssc=ssc,line1=lines[0],line2=lines[1],
                target_initial_j2000_r_km=row['r_km'],target_initial_j2000_v_km_s=row['v_km_s'],target_initial_teme_r_km=r0.tolist(),target_initial_teme_v_km_s=v0.tolist(),mean_elements=tle_mean_elements(model)))
            # Discard the entire owned in-memory scenario after fitting; no source scene is saved.
            if (j+1)%60==0 or j+1==len(rows):print('Fitted %d/%d'%(j+1,len(rows)),flush=True)
        model=Sgp4Model(records)
        model.state(np.linspace(0,DURATION,1441))
        manifest=dict(schema='sgp4_bundle_v1',status='FROZEN_SYNTHETIC_TLE',propagator='SGP4',epoch_utc=EPOCH,duration_s=DURATION,gravity='WGS72',native_frame='TEMEOfDate',output_frame='J2000',
            initial_layout='Nominal Walker-Star 18x40, F=1, 1200 km, 85 deg; target osculating J2000 initial states, not exact TLE mean-element spacing',
            synthetic=True,bstar=0,fit_method='STK GenerateTLE Point; max iterations 100; convergence 1e-10; serialized TLE re-evaluated independently',
            source_archive_manifest_sha256=sha(source/'constellation_manifest.json'),source_archive_scene_sha256=sha(source/'scenario.sc'),satellites=records)
        dump(out/'manifest.json',manifest)
        (out/'constellation.tle').write_text(''.join(r['sat_name']+'\n'+r['line1']+'\n'+r['line2']+'\n' for r in records),encoding='ascii')
        dump(out/'fit_audit.json',dict(passed=True,epoch_position_tolerance_m=25,epoch_velocity_tolerance_m_s=0.05,
            max_serialized_epoch_position_error_m=max(x['serialized_epoch_position_error_m'] for x in fits),max_serialized_epoch_velocity_error_m_s=max(x['serialized_epoch_velocity_error_m_s'] for x in fits),satellites=fits,
            interpretation='Initial fit/serialization error only; full-window difference from archived TwoBody is model divergence, not fitting error'))
        dump(out/'hashes.json',{name:sha(out/name) for name in ('manifest.json','constellation.tle')})
        Sgp4Model.load(out)
        for name,expected in prov.items():
            if sha(source/name)!=expected:raise ValueError('Archive changed during migration')
        if args.limit is None:
            bundle.mkdir(parents=True,exist_ok=False)
            for name in ('manifest.json','constellation.tle','fit_audit.json','hashes.json'):shutil.copy2(out/name,bundle/name)
            print('Frozen formal TLE bundle:',bundle,flush=True)
        status['overall']='PASS_FROZEN_TLE';print(out,flush=True)
    except Exception as exc:
        status.update(overall='FAIL',error=repr(exc));dump(out/'failure.json',dict(traceback=traceback.format_exc()));raise
    finally:
        if app is not None and owns:app.Quit()
        dump(out/'status.json',status)
        dump(out/'provenance.json',dict(source_hashes=prov,code_sha256=sha(Path(__file__)),output_hashes={f.name:sha(f) for f in out.iterdir() if f.is_file() and f.name!='provenance.json'}))

if __name__=='__main__':main()


