"""Diagnostic STK11 TLE fitting/import and native frame probe. Not a production entry."""
from pathlib import Path
import sys
import traceback
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from dynamic_lisl.common import *
from comtypes.client import CreateObject
from comtypes.gen import STKObjects
from sgp4.api import Satrec,WGS72
out=new_output('sgp4_probe');app=None;owns=False
try:
    source=PROJECT/'archive/twobody_20260921/outputs/gate_a_720_20260918T124844_819817Z'
    app=CreateObject('STK11.Application');root=app.Personality2
    if bool(root.CurrentScenario):raise RuntimeError('REFUSE_NONEMPTY_STK')
    owns=True;app.Visible=False;app.UserControl=False
    root.LoadScenario(str(source/'scenario.sc'));units(root)
    rows=read_json(source/'constellation_manifest.json');row=rows[0]
    obj=root.GetObjectFromPath('*/Satellite/'+row['source_name'])
    cmd=f'GenerateTLE */Satellite/{row["source_name"]} Point "{EPOCH}" 10000 100 0.0000000001 SGP4 "FitProbe" BStar 0'
    root.ExecuteCommand(cmd)
    res=obj.DataProviders.GetDataPrvFixedFromPath('TLE Summary Data').Exec()
    lines=list(res.DataSets.GetDataSetByName('TLE').GetValues())
    dump(out/'fitting.json',dict(command=cmd,lines=lines,dataset_count=res.DataSets.Count))
    tle=out/'probe.tle';tle.write_text('X0_1\n'+'\n'.join(lines)+'\n',encoding='ascii')
    original=rv(obj,EPOCH)
    root.CloseScenario();root.NewScenario('SGP4Probe');scene=root.CurrentScenario.QueryInterface(STKObjects.IAgScenario)
    scene.StartTime=EPOCH;scene.StopTime=utc(DURATION);scene.Epoch=EPOCH
    sat=root.CurrentScenario.Children.New(STKObjects.eSatellite,'X0_1')
    cmd=f'SetState */Satellite/X0_1 SGP4 "{EPOCH}" "{utc(DURATION)}" 30 10000 TLESource DefineElements Source File "{tle}"'
    root.ExecuteCommand(cmd)
    units(root,'EpSec');model=Satrec.twoline2rv(lines[0],lines[1],WGS72)
    results=[]
    for t in (0.,17.3,600.,86400.):
        error,r,v=model.sgp4(EPOCH_JD,t/86400)
        item=dict(t_s=t,sgp4_error=error)
        for frame in ('TEMEOfDate','TEMEOfEpoch','J2000'):
            try:
                rr,vv=rv(sat,t,frame);item[frame]=dict(position_error_m=float(np.linalg.norm(rr-r)*1000),velocity_error_m_s=float(np.linalg.norm(vv-v)*1000),r_km=rr.tolist(),v_km_s=vv.tolist())
            except Exception as exc:item[frame]=repr(exc)
        results.append(item)
    dump(out/'probe_audit.json',dict(original_j2000=[x.tolist() for x in original],results=results))
    root.SaveAs(str(out/'scenario.sc'));print(out,flush=True)
except Exception:
    dump(out/'failure.json',dict(traceback=traceback.format_exc()));raise
finally:
    if app is not None and owns:app.Quit()

