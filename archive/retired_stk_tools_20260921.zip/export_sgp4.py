"""Reload a verified SGP4 scene and export/revalidate its full ephemeris."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from dynamic_lisl.common import PROJECT,read_json
from dynamic_lisl.stk_sgp4 import run
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--scene-dir',required=True,type=Path)
p.add_argument('--step-s',type=float,default=30)
a=p.parse_args()
s=read_json(a.scene_dir/'status.json')
run(a.scene_dir,limit=s['count'],duration=s['duration_s'],step=a.step_s,source_scene=a.scene_dir/'scenario.sc')
