raise SystemExit('TwoBody entry retired. Use tools/generate_sgp4.py after migration. Historical implementation is in archive/twobody_20260921/tools/.')
