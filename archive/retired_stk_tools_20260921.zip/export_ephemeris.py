raise SystemExit('TwoBody export retired. Use tools/export_sgp4.py after migration. Historical implementation is in archive/twobody_20260921/tools/.')
