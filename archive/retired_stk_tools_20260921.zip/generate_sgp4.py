"""Create and validate a SGP4-only scene and ephemeris from frozen synthetic TLEs."""
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from dynamic_lisl.common import PROJECT
from dynamic_lisl.stk_sgp4 import run

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['smoke','720'],default='smoke')
    p.add_argument('--bundle',type=Path,default=PROJECT/'data/raw/sgp4_x720')
    p.add_argument('--step-s',type=float,default=30)
    a=p.parse_args()
    run(a.bundle,limit=12 if a.mode=='smoke' else None,duration=600 if a.mode=='smoke' else 86400,step=a.step_s)

if __name__=='__main__':main()
