"""SGP4-only STK scene creation, reload, export and window-wide validation."""
from pathlib import Path
import shutil
import traceback
import uuid
import math
import numpy as np
from .common import *
from .sgp4_model import Sgp4Model
from .ephemeris import Ephemeris,time_grid
from .sgp4_geometry import geometry_windows


def orbital_angles(r,v):
    h=np.cross(r,v);hh=h/np.linalg.norm(h)
    node=np.array([-h[1],h[0],0.]);node/=np.linalg.norm(node)
    return np.degrees([math.atan2(node[1],node[0]),math.acos(hh[2]),math.atan2(np.dot(r,np.cross(hh,node)),np.dot(r,node))])

def angle_error(a,b):return (a-b+180)%360-180


def validate_satellite(obj,root,duration):
    from comtypes.gen import STKObjects
    sat=obj.QueryInterface(STKObjects.IAgSatellite)
    if sat.PropagatorType!=STKObjects.ePropagatorSGP4:raise ValueError('NON_SGP4_SATELLITE')
    prop=sat.Propagator.QueryInterface(STKObjects.IAgVePropagatorSGP4)
    if bool(prop.AutoUpdateEnabled):raise ValueError('AUTOMATIC_TLE_UPDATE_FORBIDDEN')
    verify_date(root,prop.StartTime,EPOCH);verify_date(root,prop.StopTime,utc(duration))
    return prop


def run(bundle,limit=None,duration=DURATION,step=30.0,source_scene=None):
    bundle=Path(bundle).resolve();full_model=Sgp4Model.load(bundle)
    if not 0<duration<=full_model.duration_s:raise ValueError('INVALID_WINDOW')
    if limit is not None and not 1<=limit<=len(full_model.records):raise ValueError('INVALID_LIMIT')
    records=full_model.records if limit is None else full_model.records[:limit]
    model=Sgp4Model(records,duration)
    times=time_grid(duration,step)
    out=new_output('sgp4_geometry');status=dict(overall='RUNNING',propagator='SGP4',count=len(records),duration_s=duration,step_s=step)
    dump(out/'status.json',status);app=None;owns=False
    try:
        from comtypes.client import CreateObject
        from comtypes.gen import STKObjects
        for name in ('manifest.json','constellation.tle','fit_audit.json','hashes.json'):shutil.copy2(bundle/name,out/name)
        app=CreateObject('STK11.Application');root=app.Personality2
        if bool(root.CurrentScenario):raise RuntimeError('REFUSE_NONEMPTY_STK')
        owns=True;app.Visible=False;app.UserControl=False;units(root)
        if source_scene is None:
            root.NewScenario('SGP4_'+uuid.uuid4().hex[:10])
            scene=root.CurrentScenario.QueryInterface(STKObjects.IAgScenario)
            scene.StartTime=EPOCH;scene.StopTime=utc(duration);scene.Epoch=EPOCH
            for j,row in enumerate(records):
                obj=root.CurrentScenario.Children.New(STKObjects.eSatellite,row['sat_name'])
                command=f'SetState */Satellite/{row["sat_name"]} SGP4 "{EPOCH}" "{utc(duration)}" {step} {row["ssc"]} TLESource DefineElements Source File "{out / "constellation.tle"}"'
                root.ExecuteCommand(command)
                prop=obj.QueryInterface(STKObjects.IAgSatellite).Propagator.QueryInterface(STKObjects.IAgVePropagatorSGP4)
                prop.AutoUpdateEnabled=False
                validate_satellite(obj,root,duration)
                if (j+1)%60==0 or j+1==len(records):print('Created SGP4 %d/%d'%(j+1,len(records)),flush=True)
        else:
            source_scene=Path(source_scene).resolve()
            scene_status=read_json(source_scene.parent/'status.json')
            if scene_status.get('overall')!='PASS_SGP4_GEOMETRY':raise ValueError('SOURCE_SCENE_NOT_ACCEPTED')
            source_prov=read_json(source_scene.parent/'provenance.json')['output_hashes']
            for name,expected in source_prov.items():
                f=(source_scene.parent/name).resolve()
                if source_scene.parent not in f.parents or sha(f)!=expected:raise ValueError('SOURCE_SCENE_HASH_MISMATCH')
            if sha(source_scene.parent/'manifest.json')!=sha(bundle/'manifest.json'):raise ValueError('SOURCE_SCENE_TLE_BUNDLE_MISMATCH')
            root.LoadScenario(str(source_scene));units(root)
            scene=root.CurrentScenario.QueryInterface(STKObjects.IAgScenario)
        verify_date(root,scene.Epoch);verify_date(root,scene.StartTime);verify_date(root,scene.StopTime,utc(duration))
        objects=[root.GetObjectFromPath('*/Satellite/'+r['sat_name']) for r in records]
        if root.CurrentScenario.Children.GetElements(STKObjects.eSatellite).Count!=len(records):raise ValueError('SCENE_COUNT')
        for obj in objects:validate_satellite(obj,root,duration)
        root.SaveAs(str(out/'scenario.sc'))
        # Reload the written scene to test its persisted propagation model and TLEs.
        root.CloseScenario();root.LoadScenario(str(out/'scenario.sc'));units(root)
        objects=[root.GetObjectFromPath('*/Satellite/'+r['sat_name']) for r in records]
        for obj in objects:validate_satellite(obj,root,duration)
        actual=dict(stk_version=str(root.ExecuteCommand('GetSTKVersion /').Item(0)),units=units(root),epoch_utc=EPOCH,native_frame='TEMEOfDate',export_frame='J2000',tle_auto_update=False,scene_reload_verified=True)
        units(root,'EpSec')
        r=np.empty((len(times),len(records),3));v=np.empty_like(r)
        max_native_r=max_native_v=max_rotation_norm=0.;epoch=[]
        for j,(obj,row) in enumerate(zip(objects,records)):
            rr,vv=bulk(obj,times,step,'J2000');tr,tv=bulk(obj,times,step,'TEMEOfDate')
            pr,pv=model.state(times,[row['sat_name']]);pr,pv=pr[:,0],pv[:,0]
            max_native_r=max(max_native_r,float(np.linalg.norm(tr-pr,axis=1).max()))
            max_native_v=max(max_native_v,float(np.linalg.norm(tv-pv,axis=1).max()))
            max_rotation_norm=max(max_rotation_norm,float(np.abs(np.linalg.norm(rr,axis=1)-np.linalg.norm(tr,axis=1)).max()))
            r[:,j]=rr;v[:,j]=vv
            dr=float(np.linalg.norm(rr[0]-row['target_initial_j2000_r_km'])*1000)
            dv=float(np.linalg.norm(vv[0]-row['target_initial_j2000_v_km_s'])*1000)
            ra,inc,u=orbital_angles(rr[0],vv[0]);p,k=row['plane_id'],row['slot_id']
            epoch.append(dict(sat_name=row['sat_name'],position_error_m=dr,velocity_error_m_s=dv,
                raan_error_deg=float(angle_error(ra,p*10)),inclination_error_deg=float(inc-85),phase_error_deg=float(angle_error(u,p*0.5+k*9))))
            if (j+1)%60==0 or j+1==len(records):print('Exported/verified %d/%d'%(j+1,len(records)),flush=True)
        epoch_pass=all(x['position_error_m']<=25 and x['velocity_error_m_s']<=0.05 and max(abs(x[k]) for k in ('raan_error_deg','inclination_error_deg','phase_error_deg'))<=0.001 for x in epoch)
        native_pass=max_native_r<=0.001 and max_native_v<=1e-6 and max_rotation_norm<=1e-7
        audit=dict(passed=epoch_pass and native_pass,actual=actual,samples=len(times)*len(records),max_native_position_error_m=max_native_r*1000,max_native_velocity_error_m_s=max_native_v*1000,max_frame_radius_difference_m=max_rotation_norm*1000,epoch_checks=epoch,
            thresholds=dict(epoch_position_m=25,epoch_velocity_m_s=0.05,epoch_angles_deg=0.001,native_position_m=1,native_velocity_m_s=0.001),
            epoch_geometry_definition='osculating J2000 target layout; TLE mean elements are separately recorded and are not required to have exact 10/0.5 degree spacing')
        dump(out/'trajectory_audit.json',audit)
        if not audit['passed']:raise ValueError('TRAJECTORY_OR_INITIAL_GEOMETRY_FAILED')
        meta=dict(schema='dynamic_lisl_ephemeris_v2',propagator='SGP4',frame='J2000',native_frame='TEMEOfDate',position_unit='km',velocity_unit='km/s',time_unit='s',epoch_utc=EPOCH,interpolation='cubic_hermite',tle_bundle_sha256=sha(bundle/'manifest.json'),synthetic=True,bstar=0,gravity='WGS72',source_bundle=str(bundle))
        ep=Ephemeris(times,model.ids,r,v,meta)
        # Every satellite, every interval: fresh STK J2000 queries at three off-grid fractions.
        max_ir=max_iv=0.;checked=0
        for j,(obj,row) in enumerate(zip(objects,records)):
            for fraction in (0.2113248654051871,0.5,0.7886751345948129):
                q=times[:-1]+fraction*np.diff(times)
                # Our formal 24h/30s grid is uniform. Handle a short final interval separately.
                regular=len(q) if len(q)<2 or np.allclose(np.diff(q),step,atol=1e-8,rtol=0) else len(q)-1
                if regular:
                    qr,qv=bulk(obj,q[:regular],step,'J2000')
                else:qr=qv=np.empty((0,3))
                if regular<len(q):
                    last_r,last_v=rv(obj,float(q[-1]),'J2000');qr=np.vstack([qr,last_r]);qv=np.vstack([qv,last_v])
                ir,iv=ep.state(q,[row['sat_name']])
                max_ir=max(max_ir,float(np.linalg.norm(ir[:,0]-qr,axis=1).max()))
                max_iv=max(max_iv,float(np.linalg.norm(iv[:,0]-qv,axis=1).max()));checked+=len(q)
            if (j+1)%120==0 or j+1==len(records):print('Off-grid checked %d/%d'%(j+1,len(records)),flush=True)
        interpolation=dict(passed=max_ir<=0.001 and max_iv<=1e-5,checked_samples=checked,max_position_error_m=max_ir*1000,max_velocity_error_m_s=max_iv*1000,reference='Fresh STK SGP4 J2000 off-grid queries over every interval; no TwoBody reference',position_tolerance_m=1,velocity_tolerance_m_s=0.01)
        dump(out/'interpolation_audit.json',interpolation)
        if not interpolation['passed']:raise ValueError('SGP4_INTERPOLATION_FAILED')
        ep.save(out/'ephemeris.npz')
        loaded=Ephemeris.load(out/'ephemeris.npz')
        for t in (0.,min(17.3,duration),duration):
            a,b=ep.state(t);aa,bb=loaded.state(t)
            if not np.array_equal(a,aa) or not np.array_equal(b,bb):raise ValueError('ARCHIVE_ROUNDTRIP')
        if len(records)==720:
            for count in (160,240):
                sub=out/f'subset_{count}';sub.mkdir()
                se=Ephemeris(times,model.ids[:count],r[:,:count],v[:,:count],dict(meta,parent_ephemeris_sha256=sha(out/'ephemeris.npz'),plane_ids=list(range(count//40))))
                se.save(sub/'ephemeris.npz')
                dump(sub/'manifest.json',[dict(x,boundary_plane=x['plane_id'] in (0,count//40-1)) for x in records[:count]])
                reread=Ephemeris.load(sub/'ephemeris.npz')
                passed=np.array_equal(reread.position_km,r[:,:count]) and np.array_equal(reread.velocity_km_s,v[:,:count]) and list(reread.sat_ids)==model.ids[:count]
                dump(sub/'audit.json',dict(passed=passed,count=count,parent_ephemeris_sha256=sha(out/'ephemeris.npz'),method='Exact mother rows; no separate propagation'))
                if not passed:raise ValueError('SUBSET_FAILED')
        boundaries=[]
        if len(records)>1:
            for j in sorted(set([1,len(records)//2,len(records)-1])):
                b=geometry_windows(model,[model.ids[0],model.ids[j]],stop_s=duration)
                boundaries.append(b)
                if not b['resolution_audit']['passed']:raise ValueError('SGP4_BOUNDARY_RESOLUTION_UNSTABLE')
        dump(out/'boundary_audit.json',dict(pairs=boundaries,scope='Selected diagnostic pairs, spherical LOS plus 5000km range; not all-pair terminal/FOV certification'))
        status.update(overall='PASS_SGP4_GEOMETRY',formal_eligible=len(records)==720 and duration==DURATION,limitation='Numerical geometry and interpolation checks; no network/terminal/FOV claims')
        print('SGP4 output:',out,flush=True)
    except Exception as exc:
        status.update(overall='FAIL',error=repr(exc));dump(out/'failure.json',dict(traceback=traceback.format_exc()));raise
    finally:
        if app is not None and owns:
            try:app.Quit()
            except Exception as exc:status['cleanup_warning']=repr(exc)
        dump(out/'status.json',status)
        dump(out/'provenance.json',dict(code_hashes={str(f.relative_to(PROJECT)):sha(f) for folder in ('src','tools','tests') for f in (PROJECT/folder).rglob('*.py')},output_hashes={str(f.relative_to(out)):sha(f) for f in out.rglob('*') if f.is_file() and f.name!='provenance.json'}))
    if status.get('formal_eligible'):
        dump(PROJECT/'configs/active_geometry.json',dict(status='ACTIVE_VERIFIED_SGP4',propagator='SGP4',bundle=str(bundle.relative_to(PROJECT)),scene=str((out/'scenario.sc').relative_to(PROJECT)),ephemeris=str((out/'ephemeris.npz').relative_to(PROJECT)),ephemeris_sha256=sha(out/'ephemeris.npz'),audit=str((out/'status.json').relative_to(PROJECT))))
    return out
